import 'dart:async';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:workmanager/workmanager.dart';
import 'firebase_options.dart';
import 'loginpage.dart';
import 'package:shared_preferences/shared_preferences.dart';

const simpleTaskKey = "simpleTask";

FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    switch (task) {
      case simpleTaskKey:
        await showRandomAtasozuNotification();
        break;
    }
    return Future.value(true);
  });
}

Future<void> showRandomAtasozuNotification() async {
  final String response = await rootBundle.loadString('assets/atasozleri.txt');
  List<Map<String, String>> tempAtasozleri = [];
  List<String> lines = response.split('\n');
  for (int i = 0; i < lines.length; i++) {
    String line = lines[i].trim();
    if (line.isNotEmpty) {
      String atasozu = line;
      String anlami = '';
      if (i + 1 < lines.length && lines[i + 1].trim().isNotEmpty) {
        anlami = lines[i + 1].trim();
        i++;
      }
      tempAtasozleri.add({'atasozu': atasozu, 'anlami': anlami});
    }
  }

  Random random = Random();
  int randomIndex = random.nextInt(tempAtasozleri.length);
  Map<String, String> randomAtasozu = tempAtasozleri[randomIndex];

  const AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
    'your_channel_id', // channelId
    'your_channel_name', // channelName
    channelDescription: 'your_channel_description', // channelDescription
    importance: Importance.max,
    priority: Priority.high,
    showWhen: false,
  );
  const NotificationDetails platformChannelSpecifics =
      NotificationDetails(android: androidPlatformChannelSpecifics);
  await flutterLocalNotificationsPlugin.show(
    0,
    randomAtasozu['atasozu'],
    randomAtasozu['anlami'],
    platformChannelSpecifics,
  );
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Initialize local notifications
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  final InitializationSettings initializationSettings =
      InitializationSettings(android: initializationSettingsAndroid);
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Initialize WorkManager
  Workmanager().initialize(callbackDispatcher, isInDebugMode: false); // Change debug mode to false

  // Periodic task registration
  Workmanager().registerPeriodicTask(
    "1", // unique task name
    simpleTaskKey, // task name
    existingWorkPolicy: ExistingWorkPolicy.replace, // how to handle existing tasks with the same name
    frequency: Duration(minutes: 1), // Changed to 1 minute
    initialDelay: Duration(seconds: 10), // delay before the first run
    constraints: Constraints(
      networkType: NetworkType.not_required,
      requiresBatteryNotLow: false,
      requiresCharging: false,
      requiresDeviceIdle: false,
      requiresStorageNotLow: false,
    ),
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Atasözleri Uygulaması',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.active) {
            User? user = snapshot.data;
            if (user == null) {
              return LoginPage();
            }
            return const AtasozleriListesi();
          }
          return const CircularProgressIndicator();
        },
      ),
      routes: {
        '/home': (context) => const AtasozleriListesi(),
        '/login': (context) => LoginPage(),
        '/game': (context) => MatchingGame(),
        '/leaderboard': (context) => LeaderboardScreen(),
      },
    );
  }
}

class AtasozleriListesi extends StatefulWidget {
  const AtasozleriListesi({super.key});

  @override
  _AtasozleriListesiState createState() => _AtasozleriListesiState();
}

class _AtasozleriListesiState extends State<AtasozleriListesi> {
  List<Map<String, String>> _atasozleri = [];
  ScrollController _scrollController = ScrollController();
  Map<String, int> _letterIndex = {};

  @override
  void initState() {
    super.initState();
    _loadAtasozleri();
  }

  Future<void> _loadAtasozleri() async {
    final String response = await rootBundle.loadString('assets/atasozleri.txt');
    List<Map<String, String>> tempAtasozleri = [];
    List<String> lines = response.split('\n');
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i].trim();
      if (line.isNotEmpty) {
        String atasozu = line;
        String anlami = '';
        if (i + 1 < lines.length && lines[i + 1].trim().isNotEmpty) {
          anlami = lines[i + 1].trim();
          i++;
        }
        tempAtasozleri.add({'atasozu': atasozu, 'anlami': anlami});
      }
    }
    tempAtasozleri.sort((a, b) => a['atasozu']!.compareTo(b['atasozu']!)); // Alphabetical sort
    setState(() {
      _atasozleri = tempAtasozleri;
      for (int i = 0; i < _atasozleri.length; i++) {
        String firstLetter = _atasozleri[i]['atasozu']![0].toUpperCase();
        if (!_letterIndex.containsKey(firstLetter)) {
          _letterIndex[firstLetter] = i;
        }
      }
    });
  }

  void _scrollToLetter(String letter) {
    final index = _letterIndex[letter];
    if (index != null) {
      _scrollController.animateTo(
        index * 100.0, // Her item'in yaklaşık yüksekliği (değiştirebilirsiniz)
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Atasözleri'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),
      body: Row(
        children: [
          Container(
            width: 40,
            color: Colors.blue[100],
            child: ListView(
              children: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter) {
                return InkWell(
                  onTap: () => _scrollToLetter(letter),
                  child: Container(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      letter,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: _atasozleri.isNotEmpty
                ? Column(
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pushNamed('/game');
                        },
                        child: Text('Eşleştirme Oyunu'),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pushNamed('/leaderboard');
                        },
                        child: Text('Leaderboard'),
                      ),
                      Expanded(
                        child: ListView.builder(
                          controller: _scrollController,
                          itemCount: _atasozleri.length,
                          itemBuilder: (context, index) {
                            Map<String, String> item = _atasozleri[index];
                            return Container(
                              margin: EdgeInsets.all(8.0),
                              padding: EdgeInsets.all(16.0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10.0),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    spreadRadius: 2,
                                    blurRadius: 5,
                                    offset: Offset(0, 3), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['atasozu']!,
                                    style: TextStyle(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 8.0),
                                  Text(
                                    item['anlami']!,
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  )
                : Center(child: CircularProgressIndicator()),
          ),
        ],
      ),
    );
  }
}

class MatchingGame extends StatefulWidget {
  @override
  _MatchingGameState createState() => _MatchingGameState();
}

class _MatchingGameState extends State<MatchingGame> {
  List<Map<String, String>> _atasozleri = [];
  List<String> _shuffledProverbs = [];
  List<String> _shuffledMeanings = [];
  int _score = 0;
  int _attempts = 0;
  int _highScore = 0;
  SharedPreferences? _prefs;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _loadAtasozleri();
    _loadScore();
  }

  Future<void> _loadAtasozleri() async {
    final String response = await rootBundle.loadString('assets/atasozleri.txt');
    List<Map<String, String>> tempAtasozleri = [];
    List<String> lines = response.split('\n');
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i].trim();
      if (line.isNotEmpty) {
        String atasozu = line;
        String anlami = '';
        if (i + 1 < lines.length && lines[i + 1].trim().isNotEmpty) {
          anlami = lines[i + 1].trim();
          i++;
        }
        tempAtasozleri.add({'atasozu': atasozu, 'anlami': anlami});
      }
    }
    tempAtasozleri.shuffle();
    setState(() {
      _atasozleri = tempAtasozleri.take(5).toList(); // Get a random sample of 5
      _shuffledProverbs = _atasozleri.map((e) => e['atasozu']!).toList();
      _shuffledMeanings = _atasozleri.map((e) => e['anlami']!).toList();
      _shuffledProverbs.shuffle();
      _shuffledMeanings.shuffle();
    });
  }

  Future<void> _loadScore() async {
    _prefs = await SharedPreferences.getInstance();
    setState(() {
      _score = 0; // Oyun başında skor sıfırlanır
      _highScore = _prefs?.getInt('highScore') ?? 0;
    });
  }

  Future<void> _saveScore() async {
    final User? user = _auth.currentUser;

    if (_score > _highScore && user != null) {
      setState(() {
        _highScore = _score;
      });
      await _prefs?.setInt('highScore', _highScore);
      await _firestore.collection('leaderboard').doc(user.uid).set({
        'email': user.email,
        'highScore': _highScore,
      }, SetOptions(merge: true));
    }
    await _prefs?.setInt('score', 0); // Normal skor sıfırlanır
  }

  void _checkMatch(String proverb, String meaning) {
    if (_atasozleri.any((element) => element['atasozu'] == proverb && element['anlami'] == meaning)) {
      setState(() {
        _score += 10;
        _shuffledProverbs.remove(proverb);
        _shuffledMeanings.remove(meaning);
        if (_shuffledProverbs.isEmpty && _shuffledMeanings.isEmpty) {
          _loadAtasozleri(); // Yeni kelimeler yüklenir
        }
      });
    } else {
      setState(() {
        _attempts += 1;
        if (_attempts >= 3) {
          _showGameOverDialog();
        }
      });
    }
  }

  void _showGameOverDialog() {
    _saveScore();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Oyun Bitti'),
          content: Text('Puanınız: $_score\nEn Yüksek Puan: $_highScore'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop(); // Return to home screen
                setState(() {
                  _score = 0;
                  _attempts = 0;
                });
              },
              child: Text('Kapat'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Eşleştirme Oyunu'),
      ),
      body: _shuffledProverbs.isNotEmpty && _shuffledMeanings.isNotEmpty
          ? Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Puan: $_score', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text('Hatalı Eşleştirme: $_attempts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text('En Yüksek Puan: $_highScore', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: ListView(
                          children: _shuffledProverbs
                              .map((proverb) => Draggable<String>(
                                    data: proverb,
                                    child: Container(
                                      margin: EdgeInsets.all(8.0),
                                      padding: EdgeInsets.all(16.0),
                                      decoration: BoxDecoration(
                                        color: Colors.blue[100],
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: Text(proverb),
                                    ),
                                    feedback: Material(
                                      child: Container(
                                        margin: EdgeInsets.all(8.0),
                                        padding: EdgeInsets.all(16.0),
                                        decoration: BoxDecoration(
                                          color: Colors.blue[100],
                                          borderRadius: BorderRadius.circular(10.0),
                                        ),
                                        child: Text(proverb),
                                      ),
                                    ),
                                    childWhenDragging: Container(
                                      margin: EdgeInsets.all(8.0),
                                      padding: EdgeInsets.all(16.0),
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: Text(proverb),
                                    ),
                                  ))
                              .toList(),
                        ),
                      ),
                      VerticalDivider(thickness: 2, color: Colors.grey),
                      Expanded(
                        child: ListView(
                          children: _shuffledMeanings
                              .map((meaning) => DragTarget<String>(
                                    builder: (context, candidateData, rejectedData) {
                                      return Container(
                                        margin: EdgeInsets.all(8.0),
                                        padding: EdgeInsets.all(16.0),
                                        decoration: BoxDecoration(
                                          color: Colors.green[100],
                                          borderRadius: BorderRadius.circular(10.0),
                                        ),
                                        child: Text(meaning),
                                      );
                                    },
                                    onAccept: (proverb) {
                                      _checkMatch(proverb, meaning);
                                    },
                                  ))
                              .toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )
          : Center(child: CircularProgressIndicator()),
    );
  }
}

class LeaderboardScreen extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leaderboard'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore.collection('leaderboard').orderBy('highScore', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }
          var documents = snapshot.data!.docs;
          return ListView.builder(
            itemCount: documents.length,
            itemBuilder: (context, index) {
              var data = documents[index].data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['email'] ?? 'Unknown'),
                trailing: Text(data['highScore'].toString()),
              );
            },
          );
        },
      ),
    );
  }
}
